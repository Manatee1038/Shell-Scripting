#!/bin/bash

read -p "Department Code: " dCode
read -p "Department Name: " dName
read -p "Course Number: " cNum
read -p "Course Name: " cName
read -p "Course Schedule: " cSchedule
read -p "Course Start Date: " cStart
read -p "Course End Date: " cEnd
read -p "Course Credit Hours: " cCredit
read -p "Initial Course Enrollment: " cEnroll

dCode=${dCode^^}

if [ -f ./data/$dCode$cNum.crs ]; then
    echo ERROR: course already exists
else
    touch ./data/$dCode$cNum.crs
    echo $dCode $dName > ./data/$dCode$cNum.crs
    echo $cName >> ./data/$dCode$cNum.crs
    echo $cSchedule $cStart $cEnd >> ./data/$dCode$cNum.crs
    echo $cCredit >> ./data/$dCode$cNum.crs
    echo $cEnroll >> ./data/$dCode$cNum.crs

    echo `date` CREATED: $dCode $cNum $cName >> ./data/queries.log
fi
