#!/bin/bash

read -p "Enter a course department code and number: " dCode cNum

dCode=${dCode^^}

if [ -f data/$dCode$cNum.crs ]; then
    go=0
    let i=1
    
    while [ $go ]; do
        if [ $i -eq 2 ]; then
            read cName
            break
        else
            let i=i+1
            read line
        fi
    done < data/$dCode$cNum.crs

    rm data/$dCode$cNum.crs

    echo `date` DELETED: $dCode $cNum $cName >> data/queries.log

    echo course was successfully deleted.
else
    echo ERROR: course not found
fi
