#!/bin/bash

read -p "Enter a course department name and number: " dCode cNum

dCode=${dCode^^}

read -p "Enter an enrollment change amount: " eChange

if [ -f data/$dCode$cNum.crs ]; then
    go=0
    let i=1

    while [ $go ]; do
        if [ $i -eq 1 ]; then
            read dCode dName
            let i=i+1
        elif [ $i -eq 2 ]; then
            read cName
            let i=i+1
        elif [ $i -eq 3 ]; then
            read cSchedule cStart cEnd
            let i=i+1
        elif [ $i -eq 4 ]; then
            read cCredit
            let i=i+1
        else
            read cEnroll
            break
        fi
    done < data/$dCode$cNum.crs

    let cEnroll=$cEnroll+$eChange

    echo $dCode $dName > data/$dCode$cNum.crs
    echo $cName >> data/$dCode$cNum.crs
    echo $cSchedule $cStart $cEnd >> data/$dCode$cNum.crs
    echo $cCredit >> data/$dCode$cNum.crs
    echo $cEnroll >> data/$dCode$cNum.crs

    echo `date` ENROLLMENT: $dCode $cNum $cName changed by $eChange >> data/queries.log
else
    echo ERROR: course not found
fi
