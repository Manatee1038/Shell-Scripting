#!/bin/bash

read -p "Enter a department code and course number: " code num

code=${code^^}

if [ -f data/$code$num.crs ]; then
    go=0
    let i=1

    while [ $go ]; do
        if [ $i -eq 1 ]; then
            read dCode dName
            let i=i+1
        elif [ $i -eq 2 ]; then
            read cName
            let i=i+1
        elif [ $i -eq 3 ]; then
            read cSchedule cStart cEnd
            let i=i+1
        elif [ $i -eq 4 ]; then
            read cCredit
            let i=i+1
        else
            read cEnroll
            break
        fi
    done < data/$code$num.crs

    echo Course Department: $dCode $dName
    echo Course Number: $num
    echo Course Name: $cName
    echo Scheduled Days: $cSchedule
    echo Course Start: $cStart
    echo Course End: $cEnd
    echo Course Hours: $cCredit
    echo Enrolled Students: $cEnroll
else
    echo "ERROR: course not found"
fi
