#!/bin/bash

total=`find data -type f -name *.crs | wc -l`

echo Total course records: $total
