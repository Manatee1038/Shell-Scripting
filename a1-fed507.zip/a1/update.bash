#!/bin/bash

read -p "Department Code: " NEWdCode
read -p "Department Name: " NEWdName
read -p "Course Number: " NEWcNum
read -p "Course Name: " NEWcName
read -p "Course Schedule: " NEWcSchedule
read -p "Course Start Date: " NEWcStart
read -p "Course End Date: " NEWcEnd
read -p "Course Credit Hours: " NEWcCredit
read -p "Initial Course Enrollment: " NEWcEnroll

NEWdCode=${NEWdCode^^}

if [ -f data/$NEWdCode$NEWcNum.crs ]; then
    go=0
    let i=1
    while [ $go ]; do
        if [ $i -eq 1 ]; then
            read dCode dName
            dCode=${dCode^^}
            let i=i+1
        elif [ $i -eq 2 ]; then
            read cName
            let i=i+1
        elif [ $i -eq 3 ]; then
            read cSchedule cStart cEnd
            let i=i+1
        elif [ $i -eq 4 ]; then
            read cCredit
            let i=i+1
        else
            read cEnroll
            break
        fi
    done < data/$NEWdCode$NEWcNum.crs
    
    if [ "$NEWdName" ]; then
        dName=$NEWdName
    fi
    echo $dCode $dName > data/$NEWdCode$NEWcNum.crs


    if [ "$NEWcName" ]; then
        cName=$NEWcName
    fi
    echo $cName >> data/$NEWdCode$NEWcNum.crs

    if [ "$NEWcSchedule" ]; then
        cSchedule=$NEWcSchedule
    fi
    if [ "$NEWcStart" ]; then
        cStart=$NEWcStart
    fi
    if [ "$NEWcEnd" ]; then
        cEnd=$NEWcEnd
    fi
    echo $cSchedule $cStart $cEnd >> data/$NEWdCode$NEWcNum.crs

    if [ "$NEWcCredit" ]; then
        cCredit=$NEWcCredit
    fi
    echo $cCredit >> data/$NEWdCode$NEWcNum.crs

    if [ "$NEWcEnroll" ]; then
        cEnroll=$NEWcEnroll
    fi
    echo $cEnroll >> data/$NEWdCode$NEWcNum.crs

    echo `date` UPDATED: $NEWdCode $NEWcNum $cName >> data/queries.log
else    
    echo ERROR: course not found
fi
